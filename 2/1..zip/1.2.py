egyik = int(input("Írj be valamit: "))
masik = int(input("Írj be még valamit: "))
 
print(egyik + masik)