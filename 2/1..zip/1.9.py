sz = int(input("Mekkora legyen a szakasz?:"))


print("+", sz*"-", "+",sep='')

i = 1
while i <= sz:
    print("+",sz*"-","+", sep="") 
    break
