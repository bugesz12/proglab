n = int(input("Adjon meg egy számot!:"))
f = 1
z = 1
k = n
while n>=f:
    j = 1
    while k>j:
        print(" ",end ='')
        j+=1
    m =1
    while z>=m:
        print("o",end ='')
        m+= 1
    print()
    f+=1
    k-=1
    z+=2