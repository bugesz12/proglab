print("A print('hello') kiírja, hogy \"hello\",\nés kezd egy új sort.")

print()

print('A "\\t\" karaktert tabulátornak nevezzük.\nA következő 8-cal osztható sorszámú oszlopra lehet ugrani vele.')
