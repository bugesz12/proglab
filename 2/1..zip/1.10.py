sz = int(input("Adj meg egy számot!"))

#print("|", sz*".", "|", sep="")


print("+",sz*"-","+",sep='')
i =1
while i <= sz:
    
    print("|", sz*".", "|", sep="") 
    i += 1   
print("+",sz*"-","+",sep='')
